﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Zhaoxi.DigitalWorkshop
{
    /// <summary>
    /// RaderChart.xaml 的交互逻辑
    /// </summary>
    public partial class RaderChart : UserControl
    {
        // 针对这些数据进行雷达图的绘制
        List<double> Values = new List<double>() { 10, 20, 30, 40, 50, 60 };
        public RaderChart()
        {
            InitializeComponent();

            this.Refresh();

            this.SizeChanged += RaderChart_SizeChanged;
        }

        private void RaderChart_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            this.Refresh();
        }

        private void Refresh()
        {
            int count = Values.Count;
            if (count == 0) return;

            // 数据变化的时候
            polygon1.Points.Clear();
            polygon2.Points.Clear();
            polygon3.Points.Clear();
            polygon4.Points.Clear();
            polygon5.Points.Clear();

            // 设置区域大小
            // 
            double size = Math.Min(RenderSize.Width, RenderSize.Height);
            //this.LayoutRoot.Width = size;
            //this.LayoutRoot.Height = size;
            double radius = size / 2;  // 半径

            double angle = 360 / count;// 每个区间的角度

            for (int i = 0; i < count; i++)
            {
                // 三角函数
                polygon1.Points.Add(new Point(
                    radius + (radius - 20) * Math.Cos((angle * i - 90) * Math.PI / 180),
                    radius + (radius - 20) * Math.Sin((angle * i - 90) * Math.PI / 180)
                    ));
                polygon2.Points.Add(new Point(
                    radius + (radius - 20) * 0.25 * Math.Cos((angle * i - 90) * Math.PI / 180),
                    radius + (radius - 20) * 0.25 * Math.Sin((angle * i - 90) * Math.PI / 180)
                    ));
                polygon3.Points.Add(new Point(
                    radius + (radius - 20) * 0.5 * Math.Cos((angle * i - 90) * Math.PI / 180),
                    radius + (radius - 20) * 0.5 * Math.Sin((angle * i - 90) * Math.PI / 180)
                    ));
                polygon4.Points.Add(new Point(
                    radius + (radius - 20) * 0.75 * Math.Cos((angle * i - 90) * Math.PI / 180),
                    radius + (radius - 20) * 0.75 * Math.Sin((angle * i - 90) * Math.PI / 180)
                    ));

                polygon5.Points.Add(new Point(
                    radius + (radius - 20) * (Values[i] * 1.0 / 100) * Math.Cos((angle * i - 90) * Math.PI / 180),
                    radius + (radius - 20) * (Values[i] * 1.0 / 100) * Math.Sin((angle * i - 90) * Math.PI / 180)
                    ));
            }
        }
    }
}
