﻿using HelixToolkit.Wpf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using System.Windows.Shapes;

namespace Zhaoxi.DigitalWorkshop
{
    /// <summary>
    /// Window3D.xaml 的交互逻辑
    /// </summary>
    public partial class Window3D : Window
    {
        public Window3D()
        {
            InitializeComponent();


            // 模型的地址   string
            //string modelPath = AppDomain.CurrentDomain.BaseDirectory + "model.stl";
            string modelPath = AppDomain.CurrentDomain.BaseDirectory + "untitled.stl";
            ModelImporter import = new ModelImporter();
            var initGroup = import.Load(modelPath);

            // 材质 
            GeometryModel3D geometryModel3D = initGroup.Children[0] as GeometryModel3D;
            DiffuseMaterial diffMat = new DiffuseMaterial(new SolidColorBrush(Colors.White));
            geometryModel3D.Material = diffMat;
            geometryModel3D.BackMaterial = diffMat;

            // 基本对象加载    相机   材质    光源
            ModelVisual3D modelVisual3D = new ModelVisual3D();
            modelVisual3D.Content = initGroup;
            // 丢给ViewPort3d进行显示
            viewport3d.Children.Add(modelVisual3D);

            //viewport3d.RotateGesture = null;
            //viewport3d.Camera.Position = new Point3D(-4536.104076473774, 5507.294544912728, 1600.513142321196);
            //viewport3d.Camera.LookDirection = new Vector3D(3721.058972115802, -4664.338853391661, -505.2320663193268);
        }
    }
}
