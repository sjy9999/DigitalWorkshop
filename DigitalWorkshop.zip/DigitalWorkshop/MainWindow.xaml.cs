﻿using ScottPlot;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Zhaoxi.DigitalWorkshop
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            this.LoadPlot();
        }

        private void LoadPlot()
        {
            // 数据点   百万
            Random random = new Random(0);

            // 问题：如何做数据的动态处理？
            // MVVM模式：数据集合的绑定？思考：如何绑定动态数据
            // 疑问 ：抽奖
            double[] values = new double[10];
            int pointCount = (int)1e6;
            //for (int i = 0; i < pointCount; i++)
            {
                this.wpfPlot.plt.PlotSignal(DataGen.RandomWalk(random, pointCount));
            }
            this.wpfPlot.Refresh();
        }
    }
}
